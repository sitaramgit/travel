import { NgModule } from '@angular/core';  
import { MatButtonModule, MatDatepickerModule, MatNativeDateModule } from '@angular/material';

const materialComponents=[
  MatButtonModule, MatDatepickerModule , MatNativeDateModule 
]
@NgModule({ 
  imports: [ materialComponents  ],
  exports : [materialComponents]
})
export class SharedModule { }
