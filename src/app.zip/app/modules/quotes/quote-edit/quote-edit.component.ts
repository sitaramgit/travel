import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quote-edit',
  templateUrl: './quote-edit.component.html',
  styleUrls: ['./quote-edit.component.css']
})
export class QuoteEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
