import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customquote',
  templateUrl: './customquote.component.html',
  styleUrls: ['./customquote.component.css']
})
export class CustomquoteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
